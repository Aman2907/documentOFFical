import React, { useState } from "react";
import "../styles.css";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";

const Accodian = ({ items }) => {
  const [openIndex, setOpenIndex] = useState(null);

  const handletoggle = (index) => {
    setOpenIndex(openIndex == index ? null : index);
  };

  return (
    <>
      {items.map((item, index) => {
        return (
          <div className="App" key={index}>
            <button
              onClick={() => handletoggle(index)}
              className="accodianTitle"
            >
              {item.title}
              {openIndex === index ? (
                <FaChevronUp style={{ float: "right" }} />
              ) : (
                <FaChevronDown style={{ float: "right" }} />
              )}
            </button>

            {openIndex === index && (
              <div className="accodianContent">{item.content}</div>
            )}
          </div>
        );
      })}
    </>
  );
};

export default Accodian;

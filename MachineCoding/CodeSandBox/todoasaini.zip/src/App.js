import { useState } from "react";
import "./styles.css";

export default function App() {
  const [input, setinput] = useState("");

  const [todo, settodo] = useState([]);

  const addTodoitem = () => {
    if (input.trim() === "") return;

    const item = {
      id: todo.length + 1,
      // id:Date.now()
      text: input,
      completed: false,
    };
    settodo((prev) => [...prev, item]);
    setinput("");
  };

  const togglecomplete = (id) => {
    settodo(
      todo.map((t) => {
        if (t.id === id) {
          return {
            ...t,
            completed: !t.completed,
          };
        } else {
          return t;
        }
      })
    );
  };

  const deletetod = (id) => {
    settodo(todo.filter((t) => t.id !== id));
  };

  return (
    <div className="App">
      <div className="input-row">
        <input
          type="text"
          placeholder="Enter Todo"
          value={input}
          onChange={(e) => setinput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              addTodoitem();
            }
          }}
        />
        <button onClick={() => addTodoitem()}>Add</button>
      </div>

      <ul className="todolist">
        {todo.map((t) => (
          <li key={t.id}>
            <input
              type="checkbox"
              checked={t.completed}
              onChange={() => togglecomplete(t.id)}
            />
            <span className={t.completed ? "strikeTho" : ""}>{t.text}</span>
            <button
              style={{ marginLeft: "22px" }}
              onClick={() => deletetod(t.id)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

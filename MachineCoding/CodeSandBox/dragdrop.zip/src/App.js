import React, { useState } from "react";
import "./styles.css";

function App() {
  const [box1, setBox1] = useState(["Item A", "Item B"]);
  const [box2, setBox2] = useState(["Item C"]);

  const onDragStart = (e, item, fromBox) => {
    e.dataTransfer.setData("item", item);
    e.dataTransfer.setData("fromBox", fromBox);
  };

  const onDrop = (e, toBox) => {
    e.preventDefault();
    const item = e.dataTransfer.getData("item");
    const fromBox = e.dataTransfer.getData("fromBox");

    if (fromBox === toBox) return; // already inside

    if (fromBox === "box1") {
      setBox1(box1.filter((i) => i !== item));
      setBox2([...box2, item]);
    } else {
      setBox2(box2.filter((i) => i !== item));
      setBox1([...box1, item]);
    }
  };

  return (
    <div className="container">
      <div
        className="box"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => onDrop(e, "box1")}
      >
        <h3>Box 1</h3>
        {box1.map((item) => (
          <div
            key={item}
            draggable
            onDragStart={(e) => onDragStart(e, item, "box1")}
            className="draggable blue"
          >
            {item}
          </div>
        ))}
      </div>

      <div
        className="box"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => onDrop(e, "box2")}
      >
        <h3>Box 2</h3>
        {box2.map((item) => (
          <div
            key={item}
            draggable
            onDragStart={(e) => onDragStart(e, item, "box2")}
            className="draggable green"
          >
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;

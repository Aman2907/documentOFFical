import { useEffect, useState } from "react";
import "./styles.css";

const ProgressBar = ({ progress }) => {
  const [animated, setAnimated] = useState(0);

  useEffect(() => {
    setTimeout(() => setAnimated(progress), 100);
  }, [progress]);

  return (
    <>
      <div className="outer">
        <div
          className="inner"
          style={{
            transform: `translateX(${animated - 100}%)`,
            color: animated < 5 ? "black" : "white",
          }}
        >
          {progress}%
        </div>
      </div>
    </>
  );
};

export default function App() {
  const bars = [1, 3, 10, 50, 90];
  return (
    <>
      <div className="App">
        <h1>Progress Bar</h1>
        {/* <ProgressBar progress={50} /> */}
        {bars.map((value) => (
          <ProgressBar key={value} progress={value} />
        ))}
      </div>
    </>
  );
}

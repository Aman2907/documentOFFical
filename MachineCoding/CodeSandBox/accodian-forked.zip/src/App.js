import Accodian from "./Components/Accodian";
import "./styles.css";

export default function App() {
  const items = [
    {
      title: "Javascript Basics",
      content: "The JS is Easy to be build",
    },
    {
      title: "Javascript Basics",
      content: "The JS is Easy to be build",
    },
    {
      title: "Javascript Basics",
      content: "The JS is Easy to be build",
    },
  ];

  return <Accodian items={items} />;
}

import React, { useState, useEffect } from "react";
import "./styles.css";

function App() {
  const [color, setcolor] = useState("white");

  function toggleChange() {
    const newchange = color === "white" ? "black" : "white";
    setcolor(newchange);
  }

  useEffect(() => {
    document.body.style.backgroundColor = color;
    document.body.style.color = color === "white" ? "black" : "white";
  }, [color]);
  return (
    <>
      <div className="Container">
        <h1>background Changer</h1>
        <button className="butt" onClick={toggleChange}>
          Color Change{" color " === "white" ? " black" : " white"}
        </button>
      </div>
    </>
  );
}

export default App;
